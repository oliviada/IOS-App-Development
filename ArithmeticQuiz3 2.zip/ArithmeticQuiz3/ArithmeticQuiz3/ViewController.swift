//
//  ViewController.swift
//  ArithmeticQuiz3
//
//  Created by student on 7/15/20.
//  Copyright © 2020 olivier. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answer1Button: UIButton!
    @IBOutlet weak var answer2Button: UIButton!
    @IBOutlet weak var Answer3Button: UIButton!
    @IBOutlet weak var answer4Button: UIButton!
    @IBOutlet weak var resultButton: UILabel!
    @IBOutlet weak var NextanswerButton: UIButton!
        
    var CorrectAnswer = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Hide()
       Random()
    
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }

    
    func Random() {
        var RandomNumber =  arc4random() % 4
        RandomNumber += 1
          
        switch(RandomNumber) {
            
        case 1:
            questionLabel.text = " How much is 5 + 3 ?"
            
            answer1Button.setTitle("the answer is 4",for: UIControl.State.normal)
            
            answer2Button.setTitle("the answer is 8",for: UIControl.State.normal)
            
            Answer3Button.setTitle("the answer is 9",for: UIControl.State.normal)
            
            answer4Button.setTitle("the answer is 7",for: UIControl.State.normal)
        
            CorrectAnswer = "2"
            break
        
            
            case 2:
                questionLabel.text = " How much is 4 + 4 ?"
                
                answer1Button.setTitle("the answer is 4",for: UIControl.State.normal)
                
                answer2Button.setTitle("the answer is 8",for: UIControl.State.normal)
                
                Answer3Button.setTitle("the answer is 9",for: UIControl.State.normal)
                
                answer4Button.setTitle("the answer is 7",for: UIControl.State.normal)
            
                CorrectAnswer = "1"
                break
            
            
            case 3:
                questionLabel.text = " How much is 7 + 2 ?"
                
                answer1Button.setTitle("the answer is 4",for: UIControl.State.normal)
                
                answer2Button.setTitle("the answer is 8",for: UIControl.State.normal)
                
                Answer3Button.setTitle("the answer is 9",for: UIControl.State.normal)
                
                answer4Button.setTitle("the answer is 7",for: UIControl.State.normal)
            
                CorrectAnswer = "3"
                break
            
            
            
            case 4:
                questionLabel.text = " How much is 3 + 4 ?"
                answer1Button.setTitle("the answer is 4",for: UIControl.State.normal)
                
                answer2Button.setTitle("the answer is 8",for: UIControl.State.normal)
                
                Answer3Button.setTitle("the answer is 9",for: UIControl.State.normal)
                
                answer4Button.setTitle("the answer is 7",for: UIControl.State.normal)
            
                CorrectAnswer = "4"
               break
            
        default:
            break
        
        }
        
        
    }
    
    
    
    func Hide() {
        
        resultButton.isHidden = true
        NextanswerButton.isHidden = true
        
    }
    
    
    func Unhide() {
        
        resultButton.isHidden = false
               NextanswerButton.isHidden = false
        
    }
    
    
    
    
    
    @IBAction func answer1Action(_ sender: Any) {
    
        Unhide()
        
        if (CorrectAnswer == "2") {
        
        resultButton.text = "You go it, Correct Answer"
        
        }
            
        else {
            resultButton.text = "Sorry, Try again"
        }
        
    }
      
    
    
    
    
    @IBAction func answer2Action(_ sender: Any) {
    
    Unhide()
        
    if (CorrectAnswer == "1") {
    
    resultButton.text = "You go it, Correct Answer"
    
    }
        
    else {
        resultButton.text = "Sorry, Try again"
    }
    
    
    
    }
    
    
    @IBAction func answer3Action(_ sender: Any) {
    
    Unhide()
    if (CorrectAnswer == "3") {
    
    resultButton.text = "You go it, Correct Answer"
    
    }
        
    else {
        resultButton.text = "Sorry, Try again"
    }
    
    
    }
    
    
    
    
    
    
    @IBAction func answer4Action(_ sender: Any) {
    
    Unhide()
        
    if (CorrectAnswer == "4") {
    
    resultButton.text = "You go it, Correct Answer"
    
    }
        
    else {
        resultButton.text = "Sorry, Try again"
    }
    
    }
    
    
    
    
    @IBAction func nextquestionAction(_ sender: Any) {
    
    Random()
    Hide()
   
}

}
